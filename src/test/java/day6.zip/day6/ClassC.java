package day6;

public class ClassC extends ClassB {
	
	/*int Capitol = 100;
	int interest = 20;
	
	int Result;*/
	
	public void add2sub10div10()
	{
		//Result = Capitol+interest;
		//Result = Result-10;
		add2sub10();
		Result = Result/10;
	}

}
