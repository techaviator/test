package day6;

public class ClassA {
	
	int Capitol = 100;
	int interest = 20;
	int tax = 12;
	
	int Result;
	
	public void add()
	{
		Result = Capitol+interest;
	}

}
