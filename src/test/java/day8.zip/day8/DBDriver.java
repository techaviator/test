package day8;

public class DBDriver {
	public static void main(String[] args) throws Exception {
		Connect2Database obj = new Connect2Database();
		obj.getdbdata();
	}
	

}
