package day8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class uncheckedexceptions {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		System.out.println(4/0);
		
		/*int[] i = new int[5]; //Arrayoutofbound
		
		for(int x=0;x<=6;x++)
		{
			System.out.println(i[x]);
		}*/
		
		/*
		WebDriver driver = null;//Null point exception
		
		driver.findElement(By.linkText("Gmail")).click();
*/
	}

}
