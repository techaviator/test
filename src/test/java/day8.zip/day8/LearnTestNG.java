package day8;

import org.testng.annotations.Test;

public class LearnTestNG {

	@Test
	public void sendEmail()
	{
		System.out.println("Send Email");
	}
	
	@Test
	public void login()
	{
		System.out.println("Login");
	}
	
	@Test
	public void Logout()
	{
		System.out.println("Logout");
	}

}
