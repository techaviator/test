package day5;

public class PageC extends PageB{
	
	//int x = 100, y=200, result;
	
	public void add2Sub10div10()
	{
		/*result = x+y;
		result = result -10;*/
		add2sub10();
		result = result/10;
	}

}
