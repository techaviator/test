package day5;

public class ICICIBANK implements RBI {

	@Override
	public void loanInterest() {
		System.out.println(" THe ICICI loan interest is 13%");
		
	}

	@Override
	public void fixedDepositInterest() {
		System.out.println("The ICICI fixed intest is 5%");
		
	}
	
	public void DeepawaliBonanza()
	{
		System.out.println("THis is ICICI DIWALI offer");
	}

}
