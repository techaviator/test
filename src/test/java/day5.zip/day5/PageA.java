package day5;

public class PageA {
	
	int x=100, y=200, result;
	
	public void add()
	{
		result =x+y;
	}

}
