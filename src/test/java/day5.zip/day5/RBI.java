package day5;

public interface RBI {
	public int x=10;
	public void deposit();
	public void withdraw();
	public void loan();

}
