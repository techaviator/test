package day5;

public interface RBI {
	public String x="RBI";
	public void loanInterest();
	public void fixedDepositInterest();

}
