package day5;

public class Axis implements RBI{

	@Override
	public void loanInterest() {
		
		System.out.println(" THe AXIS loan interest is 12%");
	}

	@Override
	public void fixedDepositInterest() {
		System.out.println("The AXIS fixed intest is 6%");
		
	}
	
	public void DiwaliBonanza()
	{
		System.out.println("THis is Axis Bonanza offer");
	}

}
