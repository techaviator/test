package day5;

public class googleBingdriver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/*Googlepage g = new Googlepage();
		g.launch();
		g.getdata();
		g.tear_down();
		
		bing b = new bing();
		b.launch();
		b.getdata();
		b.tear_down();*/
		
		/*Googlepage g = new Googlepage();
		g.launch();
		g.getdata();
		g.tear_down();
		*/
		bing b = new bing();
		b.launch();
		b.getdata();
		b.tear_down();

	}

}
