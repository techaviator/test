package day5;

public class PageB extends PageA{

	//int x =50,y=30,result;
	
	public void add2sub10()
	{
		//result=x+y;
		super.add();
		System.out.println(result);
		result = result-10;
	}
	
	/*public void add()
	{
		result = 10+20+30;
	}*/
	
	public void getadd()
	{
		super.add();
	}
}
