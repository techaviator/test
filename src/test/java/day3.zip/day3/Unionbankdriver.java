package day3;

public class Unionbankdriver {
	public static void main(String[] args) {
		Unionbank_CustomizedCSS obj = new Unionbank_CustomizedCSS();
		obj.launchbrowser();
		obj.insertparameters();
		obj.validate();
		obj.tear_down();
	}

}
