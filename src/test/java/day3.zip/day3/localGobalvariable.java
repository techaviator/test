package day3;

public class localGobalvariable {
	int a,b;
	public void add()
	{
		 a = 10;
		 b = 20;
		System.out.println(a+"  "+ b);
	}
	public void display()
	{
		System.out.println(a+"  "+ b);
	}

}
