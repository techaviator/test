package day3;

public class Test {
	/*static String name = "Arun";
	static int avg = 60;
	public static void main(String[] args) {
		System.out.println("The avg of "+ name+" is" +avg);

	}*/
	/*int x=0;
	public static void main(String[] args) {
		Test test = new Test();
		if (10==10)
		{
			
			 test.x= 10;
		}
		System.out.println(test.x);
		
	}
	int y= x+1;
*/
	static int x;
public static void main(String[] args) {
	
	for(int i=0;i<10;i++)
	{
		x=x+1;
	}
	System.out.println(x);
	
}
	
	
	
}
