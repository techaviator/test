package day3;

public class Bytagname_driver {
	
	public static void main(String[] args) {
		Bytagname obj = new Bytagname();
		String URL = "http://google.com/";
		/*obj.launchbrowser(URL);
		obj.getlinktext();
		obj.tear_down();*/
		//OR
		obj.common_method(URL);
	}

}
