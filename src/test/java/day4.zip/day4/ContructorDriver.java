package day4;

public class ContructorDriver {

	public static void main(String[] args) {
		//LearningContructors l = new LearningContructors();
		LearningContructors l = new LearningContructors(10,20);
		l.print();
	}

}
