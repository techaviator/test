package day4;

public class DataEncapsulationDriver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		DataEncapsulation obj = new DataEncapsulation();
		String displayaccount = obj.displayaccount(656463);
		System.out.println(displayaccount);
		
	}

}
