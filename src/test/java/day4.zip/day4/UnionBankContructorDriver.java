package day4;

public class UnionBankContructorDriver {

	public static void main(String[] args) {
		//UnionwithContructors union = new UnionwithContructors();
		UnionwithContructors union = new UnionwithContructors("chrome","100000");
		//union.intializebrowser();
		union.setBankInfo();
		union.tearDown();

	}

}
