package day4;

public class LearnMethodDriver {

	public static void main(String[] args) {
		LearningMethod learn = new LearningMethod();
		learn.getinfo();
		learn.getinfo(100,200);
		learn.getinfo(11, 22, 33);
		learn.getinfo(11, 22, "Arun");
		

	}

}
